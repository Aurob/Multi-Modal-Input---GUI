package Main;

public class TouchControl {
    private SocketClient socket;
    public TouchControl(SocketClient socket){
        System.out.println("Touch Control started.");
        //this.socket = new SocketClient("192.168.0.118",50051);
        System.out.println("Socket connection established.");
        this.socket = socket;
    }
    public void sendData(String data){
        //this.movement.setText(data);
        this.socket.sendData("touch",data);
        
    }
    
    public void stopTouching(){
        if(socket.isOpen()){
            socket.closeConnection();
        }
    }
}
