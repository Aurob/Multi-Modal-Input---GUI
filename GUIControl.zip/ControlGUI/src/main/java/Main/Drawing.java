/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import javafx.scene.image.ImageView;
import org.opencv.core.Mat;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;
import org.opencv.core.Point;
import org.opencv.core.Size;

/**
 *
 * @author Au
 */
public class Drawing {
    private ImageView drawPane;
    private int x = 1,y = 1;
    
    public static Drawing drawing = new Drawing();
    
    public void setView(ImageView drawPane){
        this.drawPane = drawPane;
    }
    
    public void draw(){
       Mat frame = new Mat(new Size(drawPane.getFitWidth(),drawPane.getFitHeight()),0, new Scalar(0,0,0));
       //Point xy = new Point(100,100);
       Imgproc.circle(
            frame, //Matrix obj of the image
            new Point(x,y), //Center of the circle
            3, //Radius
            new Scalar(255, 0, 255), //Scalar object for color
            25 //Thickness of the circle
        );
       drawPane.setImage(Utils.mat2Image(frame));
    }
    
    public void move(String direction){
        switch(direction.trim().toLowerCase()){
            case "forward":
                y-=10;
                break;
            case "up":
                y-=10;
                break;
            case "backward":
                y+=10;
                break;
            case "down":
                y+=10;
                break;
            case "left":
                x-=10;
                break;
            case "right":
                x+=10;
                break;
            default:
                System.out.println("Invalid direction...");
                break;
        }
        draw();
    }
    
}
