                          package Main;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.opencv.core.Mat;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class controller {

    @FXML private Button hand;
    @FXML private Button voice;
    @FXML private Button touch;
    @FXML private Button main;
    @FXML private Button frameStart;
    @FXML private Button voiceStart;
    @FXML private Button forward;
    @FXML private Button backward;
    @FXML private Button left;
    @FXML private Button right;
    @FXML private Button stop;
    @FXML private Button touchStopStart;
    @FXML private Label movingInfo;
    @FXML private Label words;
    @FXML private Label connL;
    @FXML private Label outL;
    @FXML private TextField address;
    @FXML private TextField port;
    @FXML private Pane mainPane;
    @FXML private Pane handPane;
    @FXML private Pane touchPane;
    @FXML private Pane voicePane;
    @FXML private Pane graphicsPane;
    @FXML private ImageView cameraFrame;
    @FXML public ImageView drawPane;
    public CameraDetection camera;
    //private Voice voiceObject;
    public GoogleSpeechTest voiceObject;
    private TouchControl touchControl;
    private SocketClient socket;
    int currentPane = 0;
    boolean cameraOn = false;
    boolean voiceRecording = false;
    boolean touchOn = false;
    private Thread voiceRecord, cam;
    private Drawing draw = new Drawing();
    String path;
    
    public void initialize() {
        System.out.println("Starting...");
        path = controller.class.getResource("/webcam.png").getPath();
        path = (path.toCharArray()[0] == '/') ? path.substring(1) : path;
        socket = new SocketClient("::1",1234);
        draw.setView(drawPane);
    }
    
    //
    public void buttonClick(ActionEvent e) {
        //Very ugly method of converting button variable name into an integer
        Pane[] panes = {mainPane, handPane, touchPane, voicePane, graphicsPane};
        
        int buttonId = Arrays.asList("main", "hand", "touch", "voice").indexOf(
                e.toString().split("id=")[1].split(",")[0]);
        System.out.println("Pressed "+buttonId);
        if(buttonId != 1 && cameraOn){
            System.out.println(socket.isOpen());
            if(camera.stopCamera()){
                frameStart.setText("Start");
                cameraOn = false;
            }
        }
        if(buttonId != 3 && voiceRecording){
            System.out.println("Stopping voice...");
            voiceObject.endDetection();
            voiceStart.setText("Start Recording");
            voiceRecording = false;
        }
        if(buttonId == 1){
            System.out.println(socket.isOpen());
            Image i = new Image("/webcam.png");
            cameraFrame.setImage(i);
        }
        
        for (int i = 0; i < 4; i++) {
            if (panes[i].isVisible()) {
                panes[i].setVisible(false);
                panes[buttonId].setVisible(true);
            }
        }
    }

    public void startRecording() throws IOException {
        //if(socket.isOpen()){
        if (!voiceRecording) {
            voiceStart.setText("Stop Recording");
            voiceRecording = true;
            outL.setText("Voice Recording has started.");
            voiceObject = new GoogleSpeechTest(drawPane,socket,socket.isOpen(), outL);
            voiceRecord = new Thread(voiceObject);
            //voiceObject = new Voice(words);
            //voiceRecord = new Thread(voiceObject);
            voiceRecord.start();

        } else {
            System.out.println("Stopping voice...");
            voiceObject.endDetection();
            voiceStart.setText("Start Recording");
            voiceRecording = false;
            outL.setText("Voice Recording has stopped.");

        }
        //}
    }

    public void startFrames() { //Also closes frames
        
        if (cameraOn) {
            if(camera.stopCamera()){
                connL.setText("Camera recording stopped.");
                frameStart.setText("Start");
                cameraOn = false;
            }
        } else {
            if(!socket.isOpen()) connL.setText("Data not sent to a socket server. Enter Socket information on the main page.");
            frameStart.setText("Stop");
            cameraOn = true;
            
            camera = new CameraDetection(cameraFrame, drawPane, socket, socket.isOpen());
            
            camera.startCamera();
            
        }
        
    }

    public void startTouch(ActionEvent e) {
        String buttonId = e.toString().split("id=")[1].split(",")[0];  
        outL.setText("Pressed "+buttonId);
        if(socket.isOpen()){
            socket.sendData("main",buttonId); 
        }
        else{
            connL.setText("Data not sent to a socket server. Enter Socket information on the main page.");
        }
        draw.move(buttonId);
    }
    
    public void setSocket(){
        if(socket.setData(address.getText(), Integer.parseInt(port.getText()))){
            connL.setText("Socket Server connected successfully");
        }else connL.setText("Socket Server could not connect");
        
    }

}
